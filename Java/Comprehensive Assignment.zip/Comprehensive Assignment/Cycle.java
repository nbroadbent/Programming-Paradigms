public class Cycle {
	
}